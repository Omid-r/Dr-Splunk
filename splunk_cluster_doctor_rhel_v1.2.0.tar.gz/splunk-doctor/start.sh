#!/usr/bin/env bash
# ==============================================================================
# Splunk Cluster Doctor & Architecture Studio - RHEL Standalone Launcher
# Version: 1.2.0
# ==============================================================================

set -e

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)"
cd "$DIR"

echo "=========================================================="
echo " Starting Splunk Cluster Doctor (RHEL Standalone v1.2.0)"
echo "=========================================================="

# Check Node.js
if ! command -v node >/dev/null 2>&1; then
    echo "[-] Node.js is not installed."
    echo "[!] Run: sudo dnf install -y nodejs   (RHEL 8/9, Rocky, AlmaLinux)"
    echo "[!] Or:  sudo yum install -y nodejs   (RHEL 7 / CentOS 7)"
    exit 1
fi

NODE_VER=$(node -v)
echo "[+] Detected Node.js: $NODE_VER"

# Auto-detect Splunk Home if not set
if [ -z "$SPLUNK_HOME" ]; then
    if [ -d "/opt/splunk" ]; then
        export SPLUNK_HOME="/opt/splunk"
    elif [ -d "/opt/splunkforwarder" ]; then
        export SPLUNK_HOME="/opt/splunkforwarder"
    elif command -v splunk >/dev/null 2>&1; then
        export SPLUNK_HOME="$(dirname "$(dirname "$(readlink -f "$(which splunk)")")")"
    else
        export SPLUNK_HOME="/opt/splunk"
    fi
fi

# Check execution user and permissions
CURRENT_USER="$(whoami)"
CURRENT_UID="$(id -u 2>/dev/null || echo 1000)"
echo "[+] Running as user: $CURRENT_USER (UID: $CURRENT_UID)"
if [ "$CURRENT_UID" -ne 0 ] && [ "$CURRENT_USER" != "splunk" ]; then
    echo "----------------------------------------------------------"
    echo "[!] NOTICE: You are running as non-root user '$CURRENT_USER'."
    echo "[!] To allow Splunk Cluster Doctor to inspect real listening ports (ss -tulpn) and read protected .conf files:"
    echo "[!] Recommend running with: sudo ./start.sh"
    echo "[!] Or install as permanent systemd service: sudo bash install-service.sh"
    echo "----------------------------------------------------------"
fi

# Export Environment
export NODE_ENV=production
export PORT=${PORT:-3000}

echo "[+] Application Port: $PORT"
echo "[+] Target Splunk Home: $SPLUNK_HOME"
echo "----------------------------------------------------------"
echo " Access UI in your browser at: http://$(hostname -I 2>/dev/null | awk '{print $1}' || echo 'localhost'):$PORT"
echo " Press Ctrl+C to stop."
echo "=========================================================="

exec node dist/server.cjs
