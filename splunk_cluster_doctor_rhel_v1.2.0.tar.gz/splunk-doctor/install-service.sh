#!/usr/bin/env bash
# ==============================================================================
# Automated Systemd Installer for RHEL / CentOS / Rocky Linux / AlmaLinux
# ==============================================================================
set -e

if [ "$EUID" -ne 0 ]; then
  echo "[-] Please run as root: sudo bash install-service.sh"
  exit 1
fi

TARGET_DIR="/opt/splunk-doctor"
echo "[+] Installing Splunk Cluster Doctor to $TARGET_DIR..."

mkdir -p "$TARGET_DIR"
cp -r ./* "$TARGET_DIR/"
chmod -R 755 "$TARGET_DIR"
chmod +x "$TARGET_DIR"/*.sh "$TARGET_DIR"/scripts/*.sh 2>/dev/null || true

# Dynamic Node.js path discovery
NODE_PATH="$(command -v node 2>/dev/null || echo "/usr/bin/node")"
sed -i "s|ExecStart=.*|ExecStart=${NODE_PATH} /opt/splunk-doctor/dist/server.cjs|g" "$TARGET_DIR/systemd/splunk-doctor.service" 2>/dev/null || true

echo "[+] Installing systemd service: /etc/systemd/system/splunk-doctor.service"
cp "$TARGET_DIR/systemd/splunk-doctor.service" /etc/systemd/system/splunk-doctor.service

systemctl daemon-reload
systemctl enable splunk-doctor.service
systemctl restart splunk-doctor.service

# Open firewall port if firewalld is active
if systemctl is-active --quiet firewalld; then
  echo "[+] Configuring firewalld for ports 3000, 8001, 8090, 9998/tcp..."
  firewall-cmd --permanent --add-port=3000/tcp 2>/dev/null || true
  firewall-cmd --permanent --add-port=8001/tcp 2>/dev/null || true
  firewall-cmd --permanent --add-port=8090/tcp 2>/dev/null || true
  firewall-cmd --permanent --add-port=9998/tcp 2>/dev/null || true
  firewall-cmd --permanent --add-port=8193/tcp 2>/dev/null || true
  firewall-cmd --reload || true
fi

echo ""
echo "===================================================================="
echo " [SUCCESS] Splunk Cluster Doctor is installed and running!"
echo " Status:   systemctl status splunk-doctor"
echo " Logs:     journalctl -u splunk-doctor -f"
echo " Web UI:   http://$(hostname -I 2>/dev/null | awk '{print $1}' || echo 'YOUR_SERVER_IP'):3000"
echo "===================================================================="
