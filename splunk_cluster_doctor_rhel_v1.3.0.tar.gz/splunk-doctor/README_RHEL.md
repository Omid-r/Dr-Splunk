# راهنمای نصب و راه‌اندازی بسته مستقل اسپلانک کلاستر دکتر (RHEL Standalone UI)
نسخه: 1.3.0
تاریخ ساخت: 2026-09-27T12:57:19.150Z

این پکیج شامل نسخه کامل، زنده و مستقل وب و سرور Splunk Cluster Doctor است که قابلیت اجرا روی Red Hat Enterprise Linux (RHEL 8 / 9)، CentOS، Rocky Linux و AlmaLinux را داراست.

## آخرین تغییرات در این نسخه (Changelog):
- **اصلاح کامل جهت فلش‌های پورت ۹۹۹۷ TCP**: فلش‌ها و ذرات متحرک مستقیماً از Heavy Forwarder به سمت بالا و ایندکسرها (Indexer 1 و Indexer 2) اشاره می‌کنند.
- **پایشگر لحظه‌ای پورت‌ها (Instant Port Inspector)**: با کلیک روی هر پورت، پنجره جزییات، پروتکل، فایل کانفیگ حاکم و دستورات تایید سلامت لینوکس نمایش داده می‌شود.
- **موتور پروب زنده TCP Socket**: اضافه شدن اندپوینت‌های تست مستقیم ارتباط با نودهای کلاستر (`/api/splunk/remote/probe-cluster`).
- **پیکربندی داینامیک نودها**: همگام‌سازی نام‌ها و آی‌پی‌های سرورها با تنظیمات کلاستر کاربر.

---

## ۱. نحوه اجرای مستقیم و سریع:
```bash
# استخراج پکیج
tar -xzf splunk_cluster_doctor_rhel_v1.3.0.tar.gz
cd splunk-doctor

# اجرای مستقیم سرور
chmod +x start.sh
./start.sh
```
سپس مرورگر خود را باز کرده و به آدرس `http://<IP_SERVER>:3000` بروید.

---

## ۲. نصب به صورت سرویس دائمی لینوکس (Systemd Service):
برای اینکه نرم‌افزار به صورت مداوم حتی پس از ریبوت سرور فعال بماند:
```bash
sudo bash install-service.sh
```

دستورات مدیریت سرویس:
```bash
sudo systemctl status splunk-doctor    # بررسی وضعیت
sudo systemctl restart splunk-doctor   # ریستارت
sudo journalctl -u splunk-doctor -f    # لاگ‌های زنده
```

---

## ۳. باز کردن پورت در فایروال لینوکس (RHEL Firewalld):
```bash
sudo firewall-cmd --permanent --add-port=3000/tcp
sudo firewall-cmd --reload
```
